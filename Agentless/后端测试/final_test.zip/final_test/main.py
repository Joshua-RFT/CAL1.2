import utils
a = 1
b = 2
c = utils.add(a,b)
print(c)